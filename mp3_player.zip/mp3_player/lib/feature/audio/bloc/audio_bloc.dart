import 'dart:io';
import 'package:bloc/bloc.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'audio_event.dart';
import 'audio_state.dart';

class AudioBloc extends Bloc<AudioEvent, AudioState> {
  AudioBloc() : super(AudioInitial()) {
    on<DownloadAudioEvent>(_onDownloadAudio);
  }

  Future<void> _onDownloadAudio(
      DownloadAudioEvent event, Emitter<AudioState> emit) async {
    emit(AudioLoading());
    try {
      final tempDir = await getTemporaryDirectory();
      final filePath = '${tempDir.path}/audio.mp3';

      final response = await http.get(Uri.parse(event.url));
      if (response.statusCode == 200) {
        final file = File(filePath);
        await file.writeAsBytes(response.bodyBytes);
        emit(AudioLoaded(filePath));
      } else {
        emit(AudioError('Failed to download audio file'));
      }
    } catch (e) {
      emit(AudioError('Error: $e'));
    }
  }
}
