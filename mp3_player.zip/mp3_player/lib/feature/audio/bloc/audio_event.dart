import 'package:equatable/equatable.dart';

abstract class AudioEvent extends Equatable {
  const AudioEvent();

  @override
  List<Object?> get props => [];
}

class DownloadAudioEvent extends AudioEvent {
  final String url;

  const DownloadAudioEvent(this.url);

  @override
  List<Object?> get props => [url];
}

class PlayPauseAudioEvent extends AudioEvent {}
