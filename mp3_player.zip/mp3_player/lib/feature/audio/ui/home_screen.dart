import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:audio_waveforms/audio_waveforms.dart';
import 'package:mp3_player/core/color.dart';
import '../bloc/audio_bloc.dart';
import '../bloc/audio_event.dart';
import '../bloc/audio_state.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final PlayerController playerController = PlayerController();
  bool isPlaying = false;

  @override
  void initState() {
    super.initState();

    // player state change
    playerController.onPlayerStateChanged.listen((state) {
      if (state == PlayerState.initialized ||
          state == PlayerState.paused ||
          state == PlayerState.stopped) {
        isPlaying = false;
      } else if (state == PlayerState.playing) {
        isPlaying = true;
      }
      setState(() {});
    });
    playerController.onCompletion.listen((_) {
      print("Playback completed");
      playerController.stopAllPlayers();
      setState(() {
        isPlaying = false; // Reset the UI state
      });
    });
    context.read<AudioBloc>().add(const DownloadAudioEvent(
        'https://codeskulptor-demos.commondatastorage.googleapis.com/descent/background%20music.mp3'));
  }

  // Dispose the player after finish
  @override
  void dispose() {
    playerController.stopAllPlayers();
    playerController.dispose();
    super.dispose();
  }

  // toggle the player
  Future<void> _togglePlayback(String filePath) async {
    if (playerController.playerState.isPlaying) {
      await playerController.pausePlayer();
    } else if (playerController.playerState.isPaused) {
      await playerController.startPlayer();
    } else if (playerController.playerState.isStopped) {
      await playerController.preparePlayer(
          path: filePath, shouldExtractWaveform: true);
      playerController.setFinishMode(finishMode: FinishMode.stop);

      await playerController.startPlayer();
    } else if (!playerController.playerState.isInitialised) {
      await playerController.preparePlayer(
          path: filePath, shouldExtractWaveform: true);
      playerController.setFinishMode(finishMode: FinishMode.stop);

      await playerController.startPlayer();
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.gradientColor,
      body: Stack(
        children: [
          Image.asset(
            'assets/background.png',
            fit: BoxFit.cover,
          ),
          BlocBuilder<AudioBloc, AudioState>(
            builder: (context, state) {
              if (state is AudioLoading || state is AudioInitial) {
                return const Center(child: CircularProgressIndicator());
              } else if (state is AudioError) {
                return Center(child: Text('Error: ${state.message}'));
              } else if (state is AudioLoaded) {
                return Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width,
                      height: 300,
                      padding: EdgeInsets.zero,
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: [
                            AppColor.gradientColor,
                            AppColor.gradientColor,
                            AppColor.gradientColor2,
                          ],
                        ),
                        borderRadius:
                            BorderRadius.vertical(top: Radius.circular(40)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Padding(
                            padding: EdgeInsets.only(left: 25.0),
                            child: Row(
                              children: [
                                Text(
                                  "Instant Crush",
                                  style: TextStyle(
                                    fontSize: 22,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 4),
                          const Padding(
                            padding: EdgeInsets.only(left: 25.0),
                            child: Row(
                              children: [
                                Text(
                                  "feat. Julian Casablancas",
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.white70,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 16),
                          //Show the Audio wave forms
                          AudioFileWaveforms(
                            size: const Size(double.infinity, 65),
                            playerController: playerController,
                            waveformType: WaveformType.long,
                            playerWaveStyle: const PlayerWaveStyle(
                              fixedWaveColor: Colors.grey,
                              showBottom: true,
                              spacing: 10,
                              waveThickness: 4,
                              showSeekLine: false,
                              backgroundColor: Colors.transparent,
                            ),
                          ),
                          const SizedBox(height: 16),
                          GestureDetector(
                            onTap: () => _togglePlayback(state.filePath),
                            child: SizedBox(
                              height: 80,
                              width: 80,
                              child: Image.asset(
                                isPlaying
                                    ? 'assets/pause.png'
                                    : 'assets/play.png',
                                fit: BoxFit.fill,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                );
              }
              return const SizedBox();
            },
          ),
        ],
      ),
    );
  }
}
