import 'dart:ui';

class AppColor {
  static const gradientColor = Color.fromRGBO(49, 49, 49, 1);
  static const gradientColor2 = Color.fromRGBO(99, 99, 99, 1);
}
