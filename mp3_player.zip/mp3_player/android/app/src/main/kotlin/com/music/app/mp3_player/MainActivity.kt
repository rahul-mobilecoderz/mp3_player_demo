package com.music.app.mp3_player

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
